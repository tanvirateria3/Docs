﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;
using GCV.Commons;

namespace GCV.DataProcess
{
    class SqlHelper
    {
        public void UpdateAccount (BaseComponents customer)
        {
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            try
            {
                var command = new SqlCommand("uspGCVUpdate", conn);
                command.CommandType = CommandType.StoredProcedure;
                SqlParameter AccountNumber = command.Parameters.Add("@AccountNumber", SqlDbType.VarChar, 20);
                SqlParameter CreditLimit = command.Parameters.Add("@Creditlimit", SqlDbType.Money);
                SqlParameter RiskScore = command.Parameters.Add("@RiskScore", SqlDbType.VarChar, 10);
                SqlParameter CustomerServiceModelLevel = command.Parameters.Add("@CustomerServiceModelLevel", SqlDbType.VarChar, 100);
                SqlParameter CreditStatus = command.Parameters.Add("@CreditStatus", SqlDbType.VarChar, 20);
                SqlParameter VZAccountManagerContact = command.Parameters.Add("@VZAccountManagerContact", SqlDbType.VarChar, 100);
                SqlParameter VZAccountsPayableContact = command.Parameters.Add("@VZAccountsPayableContact", SqlDbType.VarChar, 100);
                SqlParameter VZClaimsMgrSupervisor = command.Parameters.Add("@VZClaimsMgrSupervisor", SqlDbType.VarChar, 100);
                SqlParameter VZSalesServiceTeamContact = command.Parameters.Add("@VZSalesServiceTeamContact", SqlDbType.VarChar, 100);
                SqlParameter WholesaleID = command.Parameters.Add("@WholesaleID", SqlDbType.Int);
                SqlParameter InternationalEnterprise = command.Parameters.Add("@InternationalEnterprise", SqlDbType.Int);
                SqlParameter CorporateBillingandCollections = command.Parameters.Add("@CorporateBillingandCollections", SqlDbType.Int);
                AccountNumber.Value = customer.AccountNumber;
                CreditLimit.Value = customer.Creditlimit;
                RiskScore.Value = customer.RiskScore;
                CustomerServiceModelLevel.Value = customer.CustomerServiceModelLevel;
                CreditStatus.Value = customer.CreditStatus;
                VZAccountManagerContact.Value = customer.VZAccountManagerContact;
                VZAccountsPayableContact.Value = customer.VZAccountsPayableContact;
                VZClaimsMgrSupervisor.Value = customer.VZClaimsMgrSupervisor;
                VZSalesServiceTeamContact.Value = customer.VZSalesServiceTeamContact;
                WholesaleID.Value = customer.WholesaleID;
                InternationalEnterprise.Value = customer.InternationalEnterprise;
                CorporateBillingandCollections.Value = customer.CorporateBillingandCollections;
                
                {
                    conn.Open();
                    var adapter = new SqlDataAdapter(command);
                }

            }
            catch
            {
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
