﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GCV.DataProcess
{
    public class GCVauditlog
    {
        public int GCVAuditLogID { get; set; }

        public string UserID { get; set; }

        public string Action { get; set; }

        public DateTime AccessDate { get; set; }
    }
}