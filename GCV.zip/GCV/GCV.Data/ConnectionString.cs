﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GCV.DataProcess
{
    public static class ConnectionString
    {
        public static string Connect()
        {
            return @"Data Source=sacg1lzrmtv04.ebiz.verizon.com,56458;Initial Catalog=DS;Persist Security Info=True;User ID=SSISETL;Password=$$!$ETL";
        }
    }
}
