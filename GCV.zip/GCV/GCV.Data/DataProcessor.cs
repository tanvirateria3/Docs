﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GCV.Commons;
using GCV;
using System.Data;
using System.Data.SqlClient;

namespace GCV.DataProcess
{
    public class DataProcessor
    {
        //public void search();
        BaseComponents customer = new BaseComponents();
        SqlHelper helper = new SqlHelper();

        #region update
        public void UpdateAccount(BaseComponents updateCustomer, List<string> accountNumbers, List<GlobalCustomerView> selectedAccounts)
        {

            foreach (string accountNumber in accountNumbers)
            {
                customer = FindCustomer(accountNumber, selectedAccounts);

                customer.Creditlimit = updateCustomer.Creditlimit;
                customer.RiskScore = updateCustomer.RiskScore;
                customer.CustomerServiceModelLevel = updateCustomer.CustomerServiceModelLevel;
                customer.CreditStatus = updateCustomer.CreditStatus;

                customer.VZAccountManagerContact = updateCustomer.VZAccountManagerContact;
                customer.VZAccountsPayableContact = updateCustomer.VZAccountsPayableContact;
                customer.VZClaimsMgrSupervisor = updateCustomer.VZClaimsMgrSupervisor;
                customer.VZSalesServiceTeamContact = updateCustomer.VZSalesServiceTeamContact;

                customer.WholesaleID = updateCustomer.WholesaleID;
                customer.InternationalEnterprise = updateCustomer.InternationalEnterprise;
                customer.CorporateBillingandCollections = updateCustomer.CorporateBillingandCollections;
                helper.UpdateAccount(customer);
            }
        }
        private GlobalCustomerView FindCustomer(string accountNumber, List<GlobalCustomerView> selectedAccounts)
        {
            foreach (GlobalCustomerView gcv in selectedAccounts)
            {
                if (gcv.AccountNumber == accountNumber)
                {
                    return gcv;
                }
                else
                {
                    return new GlobalCustomerView();
                }
            }
            return new GlobalCustomerView();
        }
        #endregion


        public DataSet Search(string id)
        {

            DataSet searchList = new DataSet();
            using (SqlConnection conn = new SqlConnection(ConnectionString.Connect()))

            using (var command = new SqlCommand("GCVSearchByNASPID", conn))
            {
                try
                {
                    command.CommandType = CommandType.StoredProcedure;
                    SqlParameter naspId = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 100);
                    naspId.Value = id;
                    {
                        conn.Open();
                        var adapter = new SqlDataAdapter(command);

                        adapter.Fill(searchList);

                    }
                }

                finally
                {
                    conn.Close();
                }
                return searchList;
            }
        }
    }
}
