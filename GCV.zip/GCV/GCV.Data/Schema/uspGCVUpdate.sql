CREATE procedure dbo.uspGCVUpdate
(
@AccountNumber varchar(20),
@Creditlimit money,
@RiskScore varchar(10),
@CustomerServiceModelLevel varchar(100),
@CreditStatus varchar(20),
@VZAccountManagerContact varchar(100),
@VZAccountsPayableContact varchar(100),
@VZClaimsMgrSupervisor varchar(100),
@VZSalesServiceTeamContact varchar(100),
@WholesaleID int,
@InternationalEnterprise bit,
@CorporateBillingandCollections bit
)
AS
begin
	
	update[dbo].[GlobalCustomerView] 
		set Creditlimit = @Creditlimit,
		RiskScore = @RiskScore,
		CustomerServiceModelLevel = @CustomerServiceModelLevel ,
		CreditStatus = @CreditStatus,
		VZAccountManagerContact = @VZAccountManagerContact,
		VZAccountsPayableContact =@VZAccountsPayableContact ,
		VZClaimsMgrSupervisor = @VZClaimsMgrSupervisor ,
		VZSalesServiceTeamContact = @VZSalesServiceTeamContact ,
		WholesaleID =@WholesaleID,
		InternationalEnterprise = @InternationalEnterprise ,
		CorporateBillingandCollections = @CorporateBillingandCollections
	where AccountNumber = @AccountNumber 
	
end	