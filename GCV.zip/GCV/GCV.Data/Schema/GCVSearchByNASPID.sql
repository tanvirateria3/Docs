CREATE PROCEDURE dbo.GCVSearchByNASPID   
( @NASPID VARCHAR(20) )
AS
BEGIN
	SELECT 
		GlobalCustomerViewID ,AccountNumber ,CustomerName ,NASPID ,NASPName ,FamilyID ,FamilyName ,ECPDID ,ECPDName
		,DUNSNumberUltimate,DUNSNumberHeadquarters ,DUNSNumberLocation ,CustomerExecutives  ,CustomerServiceModelLevel
		,CustomerAddress ,Creditlimit ,RiskScore ,CreditStatus ,ACNA ,UPD  ,ECPDIDtotallines ,Contracttotallines
		,VZCollMgrSupervisor ,VZClaimsMgrSupervisor ,VZSalesServiceTeamContact ,VZAccountManagerContact ,VZAccountsPayableContact
		,WholesaleID ,GlobalSensitiveAccountManagement ,DomesticWholesale  ,InternationalEnterprise,InternationalWholesale
		,Federal ,CorporateBillingandCollections ,EnterpriseWireline ,EnterpriseWireless ,CreatedDate ,LastmodifiedDate
	FROM dbo.GlobalCustomerView
	WHERE NASPID = @NASPID
END