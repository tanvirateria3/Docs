USE [DS]
GO

/****** Object:  Table [dbo].[GlobalCustomerView]    Script Date: 5/30/2016 2:56:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[GlobalCustomerView](
	[GlobalCustomerViewID] [bigint] IDENTITY(1,1) NOT NULL,
	[AccountNumber] [varchar](20) NULL,
	[CustomerName] [varchar](100) NULL,
	[NASPID] [varchar](20) NULL,
	[NASPName] [varchar](100) NULL,
	[FamilyID] [varchar](20) NULL,
	[FamilyName] [varchar](100) NULL,
	[ECPDID] [varchar](20) NULL,
	[ECPDName] [varchar](100) NULL,
	[DUNSNumberUltimate] [varchar](20) NULL,
	[DUNSNumberHeadquarters] [varchar](100) NULL,
	[DUNSNumberLocation] [varchar](100) NULL,
	[CustomerExecutives] [varchar](100) NULL,
	[CustomerServiceModelLevel] [varchar](100) NULL,
	[CustomerAddress] [varchar](200) NULL,
	[Creditlimit] [money] NULL,
	[RiskScore] [varchar](10) NULL,
	[CreditStatus] [varchar](20) NULL,
	[ACNA] [varchar](20) NULL,
	[UPD] [varchar](20) NULL,
	[ECPDIDtotallines] [int] NULL,
	[Contracttotallines] [int] NULL,
	[VZCollMgrSupervisor] [varchar](100) NULL,
	[VZClaimsMgrSupervisor] [varchar](100) NULL,
	[VZSalesServiceTeamContact] [varchar](100) NULL,
	[VZAccountManagerContact] [varchar](100) NULL,
	[VZAccountsPayableContact] [varchar](100) NULL,
	[WholesaleID] [int] NULL,
	[GlobalSensitiveAccountManagement] [bit] NULL,
	[DomesticWholesale] [bit] NULL,
	[InternationalEnterprise] [bit] NULL,
	[InternationalWholesale] [bit] NULL,
	[Federal] [bit] NULL,
	[CorporateBillingandCollections] [bit] NULL,
	[EnterpriseWireline] [bit] NULL,
	[EnterpriseWireless] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[LastmodifiedDate] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO


