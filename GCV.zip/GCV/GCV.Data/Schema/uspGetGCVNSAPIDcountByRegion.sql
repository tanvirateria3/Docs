CREATE procedure dbo.uspGetGCVNSAPIDcountByRegion
( @accountnaspid varchar(10))
AS
/*--------------------
 dbo.uspGetGCVNSAPIDcountByRegion '10EMCX' 
 dbo.uspGetGCVNSAPIDcountByRegion  '10WTBE'
 dbo.uspGetGCVNSAPIDcountByRegion  'A24680'
 dbo.uspGetGCVNSAPIDcountByRegion  'B97531'
 dbo.uspGetGCVNSAPIDcountByRegion  'C24680'
-------------------*/
Begin
declare @t table(datashareaccountid int,partitionid tinyint)                 

INSERT INTO @t(datashareaccountid,partitionid)
Select DISTINCT Datashareaccountid,PartitionID 
from (
 SELECT aer.DataShareAccountID, aer.PartitionID      
  FROM Account.ENTRelationInfo aer (nolock)      
  WHERE (aer.TCMSNASPID=@accountnaspid)       
 Union All      
  SELECT aef.DataShareAccountID, aef.PartitionID      
  FROM Account.ErefInfo aef (nolock)      
  WHERE (aef.LegacyAccountID=@accountnaspid)    
     Union All      
  select da.datashareaccountid, da.partitionid              
     from Account.DataShareAccountMaster da (nolock)               
     join Account.ENTRelationInfo ar (nolock) on da.datashareaccountid = ar.datashareaccountid and da.partitionid = ar.partitionid             
     Join account.accountNasp ANP(Nolock) on Ar.ErefNaspid =ANP.AccountNaspID           
     Where (left(ANP.NaspID,6)=@accountnaspid)
      Union All         
     SELECT distinct DataShareAccountID , PartitionID           
  from  Account.ENTRelationInfo (nolocK)        
  Where (LEFT(AccountNaspID,6)=@accountnaspid)
  
  ) as N

   
SELECT -- t.*,
 lr.LocationRegionAbbreviation, count(*) as count
FROM @t t
join Address.AccountAddress aa (nolock) on t.datashareaccountid  = aa.datashareaccountid and t.partitionId = aa.partitionId
join Reference.Location l(nolock) on aa.LocationId = l.LocationId 
join Reference.LocationRegion lr(nolock) on l.locationregionid = lr.locationregionid 
group by lr.LocationRegionAbbreviation
end