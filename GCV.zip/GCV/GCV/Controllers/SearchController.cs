﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GCV.DataProcess;
using System.Data;
using System.Data.SqlClient;
using GCV.Models;
using System.Web.Helpers;

namespace GCV.Controllers
{
    public class SearchController : Controller
    {
        
        DataProcessor dataProcessor = new DataProcessor();
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Results(string responsables, bool checkResp = false)
        {
            string id = Request["SearchBox"].ToString();
            List<GCV.Models.GlobalCustomerView> search = new List<GCV.Models.GlobalCustomerView>();
            DataSet globalCustomers = dataProcessor.Search(id);
            if (globalCustomers.Tables.Count > 0 && globalCustomers.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in globalCustomers.Tables[0].Rows)
                {
                    search.Add(new GCV.Models.GlobalCustomerView
                        {
                            GlobalCustomerViewID = Convert.ToInt64(dr["GlobalCustomerViewID"].ToString()),
                            AccountNumber = Convert.ToString(dr["AccountNumber"]),
                            CustomerName = Convert.ToString(dr["CustomerName"]),
                            NASPID = Convert.ToString(dr["NASPID"]),
                            NASPName = Convert.ToString(dr["NASPName"]),
                            FamilyID = Convert.ToString(dr["FamilyID"]),
                            FamilyName = Convert.ToString(dr["FamilyName"]),
                            ECPDID = Convert.ToString(dr["ECPDID"]),
                            ECPDName = Convert.ToString(dr["ECPDName"]),
                            DUNSNumberUltimate = Convert.ToString(dr["DUNSNumberUltimate"]),
                            DUNSNumberHeadquarters = Convert.ToString(dr["DUNSNumberHeadquarters"]),
                            DUNSNumberLocation = Convert.ToString(dr["DUNSNumberLocation"]),
                            CustomerExecutives = Convert.ToString(dr["CustomerExecutives"]),
                            CustomerServiceModelLevel = Convert.ToString(dr["CustomerServiceModelLevel"]),
                            CustomerAddress = Convert.ToString(dr["CustomerAddress"]),
                            Creditlimit = Convert.ToDecimal(dr["Creditlimit"]),
                            RiskScore = Convert.ToString(dr["RiskScore"]),
                            CreditStatus = Convert.ToString(dr["CreditStatus"]),
                            ACNA = Convert.ToString(dr["ACNA"]),
                            UPD = Convert.ToString(dr["UPD"]),
                            ECPDIDtotallines = Convert.ToInt32(dr["ECPDIDtotallines"].ToString()),
                            Contracttotallines = Convert.ToInt32(dr["Contracttotallines"]),
                            VZCollMgrSupervisor = Convert.ToString(dr["VZCollMgrSupervisor"]),
                            VZClaimsMgrSupervisor = Convert.ToString(dr["VZClaimsMgrSupervisor"]),
                            VZSalesServiceTeamContact = Convert.ToString(dr["VZSalesServiceTeamContact"]),
                            VZAccountManagerContact = Convert.ToString(dr["VZAccountManagerContact"]),
                            VZAccountsPayableContact = Convert.ToString(dr["VZAccountsPayableContact"]),
                            WholesaleID = Convert.ToInt32(dr["WholesaleID"].ToString()),
                            GlobalSensitiveAccountManagement = Convert.ToBoolean(dr["GlobalSensitiveAccountManagement"].ToString()),
                            DomesticWholesale = Convert.ToBoolean(dr["DomesticWholesale"].ToString()),
                            InternationalEnterprise = Convert.ToBoolean(dr["InternationalEnterprise"].ToString()),
                            InternationalWholesale = Convert.ToBoolean(dr["InternationalWholesale"].ToString()),
                            Federal = Convert.ToBoolean(dr["Federal"].ToString()),
                            CorporateBillingandCollections = Convert.ToBoolean(dr["CorporateBillingandCollections"].ToString()),
                            EnterpriseWireline = Convert.ToBoolean(dr["EnterpriseWireline"].ToString()),
                            EnterpriseWireless = Convert.ToBoolean(dr["EnterpriseWireless"].ToString()),
                            CreatedDate = Convert.ToDateTime(dr["CreatedDate"].ToString()),
                            LastmodifiedDate = Convert.ToDateTime(dr["LastmodifiedDate"].ToString())
                        });
                }
            }
            return View(search);
        }

        [HttpPost]
        public ActionResult SelectedAccount(List<GCV.Models.GlobalCustomerView> select, string responsables, bool checkResp = false)
        {
            DataProcessor dataProcessor = new DataProcessor();
           

            return RedirectToAction("../Update/Index");
        }


    }
}
