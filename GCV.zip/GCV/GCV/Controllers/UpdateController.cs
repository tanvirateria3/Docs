﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GCV.DataProcess;
using GCV.Commons;

namespace GCV.Controllers
{
    public class UpdateController : Controller
    {
        UpdateAccountModel updatedFields = new UpdateAccountModel();
        DataProcessor processor = new DataProcessor();
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UpdateAccount()
        {
            //updatedFields.Creditlimit = (Request["txtCreditlimit"]);
            //updatedFields.RiskScore = (Request["txtRiskScore"].ToString());
            //updatedFields.CreditStatus =(Request["txtCreditStatus"].ToString());
            //updatedFields.CustomerServiceModelLevel = (Request["txtCustomerServiceModelLevel"].ToString());
            //updatedFields.VZAccountManagerContact = (Request["txtVZAccountManagerContact"].ToString());
            //updatedFields.VZAccountsPayableContact= (Request["txtVZAccountsPayableContact"].ToString());
            //updatedFields.VZClaimsMgrSupervisor = (Request["txtVZClaimsMgrSupervisor"].ToString());
            //updatedFields.VZSalesServiceTeamContact = (Request["txtVZSalesServiceTeamContact"].ToString());
            //var InternationalEnterprise=Request["rBInternationalEnterprise"];
            //var CorporateBillingandCollections = Request["rBCorporateBillingandCollections"];
            //updatedFields.InternationalEnterprise = Convert.ToBoolean(InternationalEnterprise);
            //updatedFields.CorporateBillingandCollections = Convert.ToBoolean(CorporateBillingandCollections);
            ////processor.UpdateAccount(updatedFields);
            ////Return the list of selected account numbers and Seardh result object list
            return View();
        }


    }
}
