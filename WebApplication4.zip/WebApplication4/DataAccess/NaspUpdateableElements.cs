﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class NaspUpdateableElements
    {
        public decimal creditLimit { get; set; }
        public string riskScore { get; set; }
        public string ACNA { get; set; }
    }
}