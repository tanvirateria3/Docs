﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using System.Web.Script.Serialization;

namespace WebApplication4.DataAccess
{
    public class PullChartData
    {
        private DataTable dataTable = new DataTable();
        DataSet ds = new DataSet();

        public PullChartData()
        {

        }
        public string familyidDet = string.Empty;
        public string billName = string.Empty;
        public string billAdd = string.Empty;
        public string PullFamilyData(string familyid)
        {
            string query = "GCVGraphFamilyID";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand cmnd = new SqlCommand(query, conn);
            cmnd.CommandType = CommandType.StoredProcedure;
            cmnd.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = familyid;
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmnd);
            da.Fill(ds);
            string jsonString = string.Empty;
            string returningString = string.Empty;

            if (ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
            {
                jsonString = JsonConvert.SerializeObject(ds.Tables[0]);
                familyidDet = ds.Tables[1].Rows[0][0].ToString();
                billName = ds.Tables[1].Rows[0][1].ToString();
                billAdd = ds.Tables[1].Rows[0][2].ToString();
                returningString = jsonString + "~" + familyidDet + "~" + billName + "~" + billAdd;
                conn.Close();

            }
            return returningString;



        }
        public string PullABasicDetails(string naspid)
        {
            string query = "GCVGraphNASPIDAmount";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand cmnd = new SqlCommand(query, conn);
            cmnd.CommandType = CommandType.StoredProcedure;
            cmnd.Parameters.Add("@NASPID", SqlDbType.VarChar, 20).Value = naspid;
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmnd);
            DataTable dta = new DataTable();
            da.Fill(dta);
            string jsonStrn = string.Empty;
            foreach (DataRow dr in dta.Rows)
            {
                string category = dr["name"].ToString();
                jsonStrn += "'" + category + "',";
            }
            jsonStrn = jsonStrn.TrimEnd(',');
            conn.Close();
            return jsonStrn;
        }

        public string PullABasicData(string naspid)
        {
            string query = "GCVGraphNASPIDAmount";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand cmnd = new SqlCommand(query, conn);
            cmnd.CommandType = CommandType.StoredProcedure;
            cmnd.Parameters.Add("@NASPID", SqlDbType.VarChar, 20).Value = naspid;
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmnd);
            DataTable dtab = new DataTable();
            da.Fill(dtab);
            string jsonStr = string.Empty;
            jsonStr += "{name: 'Past Due', data: [";
            foreach (DataRow dr in dtab.Rows)
            {
                string category = dr["Pastdue"].ToString();
                jsonStr += category + ",";
            }
            jsonStr = jsonStr.TrimEnd(',');
            jsonStr += "]},{name: 'Total Due', data: [";
            foreach (DataRow dr in dtab.Rows)
            {
                string value = dr["TotalDue"].ToString();
                jsonStr += value + ",";
            }
            jsonStr = jsonStr.TrimEnd(',');
            jsonStr += "]}";
            conn.Close();
            return jsonStr;
        }

        public DataTable dtb = new DataTable();
        public string PullDrilldownData(string familyid)
        {
            string query = "GCVGraphFamilyIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = familyid;
            comm.Parameters.Add("@AccountType", SqlDbType.VarChar, 1).Value = 'D';
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter dar = new SqlDataAdapter(comm);
            dar.Fill(dt);
            string jsondata = string.Empty;
            foreach (DataRow r in dt.Rows)
            {
                jsondata += ",";
                string region = r["Region"].ToString();
                string value = r["Total"].ToString();
                jsondata += "['" + region + "'," + value + "]";
                jsondata = jsondata.TrimStart(',');

            }
            conn.Close();
            return jsondata;
        }

        public string PullDrilldownIData(string familyid)
        {
            string query = "GCVGraphFamilyIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = familyid;
            comm.Parameters.Add("@AccountType", SqlDbType.VarChar, 1).Value = 'I';
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter dar = new SqlDataAdapter(comm);
            dar.Fill(dt);
            string jsondata = string.Empty;
            foreach (DataRow r in dt.Rows)
            {
                jsondata += ",";
                string region = r["Region"].ToString();
                string value = r["Total"].ToString();
                jsondata += "['" + region + "'," + value + "]";
                jsondata = jsondata.TrimStart(',');

            }
            conn.Close();
            return jsondata;
        }

        public string PullDrilldownWData(string familyid)
        {
            string query = "GCVGraphFamilyIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = familyid;
            comm.Parameters.Add("@AccountType", SqlDbType.VarChar, 1).Value = 'W';
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter dar = new SqlDataAdapter(comm);
            dar.Fill(dt);
            string jsondata = string.Empty;
            foreach (DataRow r in dt.Rows)
            {
                jsondata += ",";
                string region = r["Region"].ToString();
                string value = r["Total"].ToString();
                jsondata += "['" + region + "'," + value + "]";
                jsondata = jsondata.TrimStart(',');

            }
            conn.Close();
            return jsondata;
        }

        public string PullDrilldownHData(string familyid)
        {
            string query = "GCVGraphFamilyIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = familyid;
            comm.Parameters.Add("@AccountType", SqlDbType.VarChar, 1).Value = 'H';
            conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter dar = new SqlDataAdapter(comm);
            dar.Fill(dt);
            string jsondata = string.Empty;
            foreach (DataRow r in dt.Rows)
            {
                jsondata += ",";
                string region = r["Region"].ToString();
                string value = r["Total"].ToString();
                jsondata += "['" + region + "'," + value + "]";
                jsondata = jsondata.TrimStart(',');

            }
            conn.Close();
            return jsondata;
        }

        public string PullAnyIdData(string id, string type)
        {
            string query = "GCVGraphIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand cmnd = new SqlCommand(query, conn);
            cmnd.CommandType = CommandType.StoredProcedure;

           
            if (type == "N")
            {
                cmnd.Parameters.Add("@NASPID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "E")
            {
                cmnd.Parameters.Add("@ECPDID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "I")
            {
                cmnd.Parameters.Add("@NSAPID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "W")
            {
                cmnd.Parameters.Add("@WHOLESALEID", SqlDbType.VarChar, 20).Value = id;
            }
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmnd);
            da.Fill(ds);
            string jsonStrng = string.Empty;
            string returningString = string.Empty;
            if (ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
            {
                jsonStrng = JsonConvert.SerializeObject(ds.Tables[0]);
                familyidDet = ds.Tables[1].Rows[0][0].ToString();
                billName = ds.Tables[1].Rows[0][1].ToString();
                billAdd = ds.Tables[1].Rows[0][2].ToString();
                returningString = jsonStrng + "~" + familyidDet + "~" + billName + "~" + billAdd;
                conn.Close();
            }

            return returningString;
            
        }

        public string PullAnyIdData(string id, string type, string AccountType)
        {
            string query = "GCVGraphIDDrillDown";
            SqlConnection conn = new SqlConnection(ConnectionString.Connect());
            SqlCommand cmnd = new SqlCommand(query, conn);
            cmnd.CommandType = CommandType.StoredProcedure;

            if (type == "F")
            {
                cmnd.Parameters.Add("@FAMILYID", SqlDbType.VarChar, 20).Value = id;
                cmnd.Parameters.Add("@AccountType", SqlDbType.VarChar, 20).Value = AccountType;
            }
            else if (type == "N")
            {
                cmnd.Parameters.Add("@NASPID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "E")
            {
                cmnd.Parameters.Add("@ECPDID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "I")
            {
                cmnd.Parameters.Add("@NSAPID", SqlDbType.VarChar, 20).Value = id;
            }
            else if (type == "W")
            {
                cmnd.Parameters.Add("@WHOLESALEID", SqlDbType.VarChar, 20).Value = id;
            }
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmnd);
            da.Fill(ds);
            string jsonStrng = string.Empty;
            if (ds.Tables != null)
            {
                jsonStrng = JsonConvert.SerializeObject(ds.Tables[0]);
                familyidDet = ds.Tables[1].Rows[0][0].ToString();
                billName = ds.Tables[1].Rows[0][1].ToString();
                billAdd = ds.Tables[1].Rows[0][2].ToString();
            }
            string returningString = jsonStrng + "~" + familyidDet + "~" + billName + "~" + billAdd;
            conn.Close();
            return returningString;

        }
    }
}