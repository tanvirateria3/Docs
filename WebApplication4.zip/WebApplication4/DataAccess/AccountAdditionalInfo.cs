﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class AccountAdditionalInfo
    {
        public string AccountNumber { get; set; }
        public string DUNSNumberUltimate { get; set; }
        public string DUNSNumberHeadquarters { get; set; }
        public string DUNSNumberLocation { get; set; }
        public Nullable<int> ECPDIDtotallines { get; set; }
        public Nullable<int> Contracttotallines { get; set; }
        public string VZCollMgrSupervisor { get; set; }
        public Nullable<bool> GlobalSensitiveAccountManagement { get; set; }
        public Nullable<bool> DomesticWholesale { get; set; }
        public Nullable<bool> InternationalWholesale { get; set; }
        public Nullable<bool> Federal { get; set; }
        public Nullable<bool> EnterpriseWireline { get; set; }
        public Nullable<bool> EnterpriseWireless { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public Nullable<System.DateTime> LastmodifiedDate { get; set; }
    }
}