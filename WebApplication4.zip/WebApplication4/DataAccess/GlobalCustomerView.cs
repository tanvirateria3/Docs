﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class GlobalCustomerView : UpdateableElements
    {
        public long GlobalCustomerViewID { get; set; }
        public string CustomerName { get; set; }
        public string NASPID { get; set; }
        public string NASPName { get; set; }
        public string FamilyID { get; set; }
        public string FamilyName { get; set; }
        public string ECPDID { get; set; }
        public string ECPDName { get; set; }
        public string CustomerExecutives { get; set; }
        public string CustomerAddress { get; set; }
        public string ACNA { get; set; }
        public string UPD { get; set; }
    }
}