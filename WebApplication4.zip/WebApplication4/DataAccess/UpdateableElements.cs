﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class UpdateableElements
    {
        public string AccountNumber { get; set; }
        public Nullable<decimal> Creditlimit { get; set; }
        public string RiskScore { get; set; }
        public string CustomerServiceModelLevel { get; set; }
        public string CreditStatus { get; set; }
        public string VZAccountManagerContact { get; set; }
        public string VZAccountsPayableContact { get; set; }
        public string VZClaimsMgrSupervisor { get; set; }
        public string VZSalesServiceTeamContact { get; set; }
        public Nullable<int> WholesaleID { get; set; }
        public Nullable<bool> InternationalEnterprise { get; set; }
        public Nullable<bool> CorporateBillingandCollections { get; set; }
    }
}