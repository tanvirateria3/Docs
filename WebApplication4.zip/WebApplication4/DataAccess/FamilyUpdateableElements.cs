﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class FamilyUpdateableElements
    {
        public string familyName { get; set; }
    }
}