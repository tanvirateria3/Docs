﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace WebApplication4.DataAccess
{
    public class SqlPlayer
    {
        SqlConnection conn = new SqlConnection(ConnectionString.Connect());

        #region Update
            public void UpdateAccount(UpdateableElements updatedFields,List<string> accountNumbers,string updateNaspID)
            {
                foreach (string accountNumber in accountNumbers)
                {
                    try
                    {
                        var command = new SqlCommand("uspGCVUpdate", conn);
                        command.CommandType = CommandType.StoredProcedure;

                        #region UpdateParameters validator
                        {
                            SqlParameter AccountNumber = command.Parameters.Add("@AccountNumber", SqlDbType.VarChar, 20);
                            AccountNumber.Value = accountNumber;

                            SqlParameter NaspID = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 20);
                            NaspID.Value = updateNaspID;

                            if (updatedFields.Creditlimit != 0)
                            {
                                SqlParameter CreditLimit = command.Parameters.Add("@Creditlimit", SqlDbType.Money);
                                CreditLimit.Value = updatedFields.Creditlimit;
                            }
                    
                            if(updatedFields.RiskScore!="")
                            {
                                SqlParameter RiskScore = command.Parameters.Add("@RiskScore", SqlDbType.VarChar, 10);
                                RiskScore.Value = updatedFields.RiskScore;
                            }

                            if(updatedFields.CustomerServiceModelLevel!="")
                            {
                                SqlParameter CustomerServiceModelLevel = command.Parameters.Add("@CustomerServiceModelLevel", SqlDbType.VarChar, 100);
                                CustomerServiceModelLevel.Value = updatedFields.CustomerServiceModelLevel;
                            }

                            if(updatedFields.CreditStatus!="")
                            {
                                SqlParameter CreditStatus = command.Parameters.Add("@CreditStatus", SqlDbType.VarChar, 20);
                                CreditStatus.Value = updatedFields.CreditStatus;
                            }

                            if(updatedFields.VZAccountManagerContact!="")
                            {
                                SqlParameter VZAccountManagerContact = command.Parameters.Add("@VZAccountManagerContact", SqlDbType.VarChar, 100);
                                VZAccountManagerContact.Value = updatedFields.VZAccountManagerContact;
                            }


                            if(updatedFields.VZAccountsPayableContact!="")
                            {
                                SqlParameter VZAccountsPayableContact = command.Parameters.Add("@VZAccountsPayableContact", SqlDbType.VarChar, 100);
                                VZAccountsPayableContact.Value = updatedFields.VZAccountsPayableContact;
                            }

                            if(updatedFields.VZClaimsMgrSupervisor!="")
                            {
                                SqlParameter VZClaimsMgrSupervisor = command.Parameters.Add("@VZClaimsMgrSupervisor", SqlDbType.VarChar, 100);
                                VZClaimsMgrSupervisor.Value = updatedFields.VZClaimsMgrSupervisor;
                            }

                            if(updatedFields.VZSalesServiceTeamContact!="")
                            {
                                SqlParameter VZSalesServiceTeamContact = command.Parameters.Add("@VZSalesServiceTeamContact", SqlDbType.VarChar, 100);
                                VZSalesServiceTeamContact.Value = updatedFields.VZSalesServiceTeamContact;
                            }
                            if (updatedFields.WholesaleID != 0)
                            {
                                SqlParameter WholesaleID = command.Parameters.Add("@WholesaleID", SqlDbType.Int);
                                WholesaleID.Value = updatedFields.WholesaleID;
                            }
                        }

                        #endregion 

                        SqlParameter InternationalEnterprise = command.Parameters.Add("@InternationalEnterprise", SqlDbType.Int);
                        SqlParameter CorporateBillingandCollections = command.Parameters.Add("@CorporateBillingandCollections", SqlDbType.Int);
               
                        InternationalEnterprise.Value = updatedFields.InternationalEnterprise;
                        CorporateBillingandCollections.Value = updatedFields.CorporateBillingandCollections;

                        {
                            conn.Open();
                            int errorCount = command.ExecuteNonQuery();
                        }
                    }
                    catch (NullReferenceException)
                    {

                    }
                    finally
                    {
                        conn.Close();
                    }
            
                }
            
            }

            internal void UpdateFamilyInfo(string familyID, FamilyUpdateableElements updatedFields)
            {
                try
                {
                    var command = new SqlCommand("uspGCVUpdateFamily", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    if (updatedFields.familyName != "")
                    {
                        SqlParameter familyName = command.Parameters.Add("@FamilyName", SqlDbType.VarChar, 100);
                        familyName.Value = updatedFields.familyName;
                    }
                    SqlParameter FamilyID = command.Parameters.Add("@familyID", SqlDbType.VarChar, 20);
                    FamilyID.Value = familyID;
                    conn.Open();
                    int errorCount = command.ExecuteNonQuery();
                }
                catch (NullReferenceException)
                {
                }
                finally
                {
                    conn.Close();
                }
            }

            internal void UpdateNaspInfo(string naspID, NaspUpdateableElements updatedFields)
            {
                try
                {
                    var command = new SqlCommand("uspGCVUpdateNasp", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    if(naspID != "")
                    {
                        SqlParameter NaspID = command.Parameters.Add("@naspID", SqlDbType.VarChar, 20);
                        NaspID.Value = naspID;
                    }
                    if(updatedFields.riskScore != "")
                    {
                        SqlParameter riskScore = command.Parameters.Add("@riskScore", SqlDbType.VarChar, 10);
                        riskScore.Value = updatedFields.riskScore;
                    }
                    if (updatedFields.creditLimit != 0)
                    {
                        SqlParameter creditLimit = command.Parameters.Add("@creditLimit", SqlDbType.Money);
                        creditLimit.Value = updatedFields.creditLimit;
                    }
                    if (updatedFields.ACNA != "")
                    {
                        SqlParameter ACNA = command.Parameters.Add("@ACNA", SqlDbType.VarChar, 20);
                        ACNA.Value = updatedFields.ACNA;
                    }

                    {
                        conn.Open();
                        int errorCount = command.ExecuteNonQuery();
                    }
                }
                catch (NullReferenceException)
                {

                }
                finally
                {
                    conn.Close();
                }
            
            }

        #endregion

        #region Search and Account Additional Info

        public DataSet SearchAccount(string searchCriteria, string searchParameter,string accountType="", string region="")
            {
                DataSet dsSearchResult = new DataSet();
                try
                {
                    var command = new SqlCommand("GCVSearchByNASPID", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    if (searchCriteria == "N")
                    {
                        SqlParameter naspID = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 20);
                        naspID.Value = searchParameter;
                    }
                    else if (searchCriteria == "F")
                    {
                        SqlParameter familyID = command.Parameters.Add("@FamilyID", SqlDbType.VarChar, 20);
                        familyID.Value = searchParameter;
                    }
                    else if(searchCriteria=="E")
                    {
                        SqlParameter ECPDID = command.Parameters.Add("@ECPDID", SqlDbType.VarChar, 20);
                        ECPDID.Value = searchParameter;
                    }
                    else if (searchCriteria=="A")
                    {
                        SqlParameter accountNumber = command.Parameters.Add("@accountNUmber", SqlDbType.VarChar, 20);
                        accountNumber.Value = searchParameter;
                    }
                    else if (searchCriteria=="W")
                    {
                        SqlParameter WholeSaleID = command.Parameters.Add("@WholeSaleID", SqlDbType.VarChar, 20);
                        WholeSaleID.Value = searchParameter;
                    }
                    else if (searchCriteria == "I")
                    {
                        SqlParameter nSAPID = command.Parameters.Add("@nSAPID", SqlDbType.VarChar, 20);
                        nSAPID.Value = searchParameter;
                    } 
                    conn.Open();
                    var adapter = new SqlDataAdapter(command);

                    adapter.Fill(dsSearchResult);
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }

                return dsSearchResult;
            }

            public DataSet AccountAdditionalInfo(string accountNumber)
            {
                DataSet accountAdditionalInfo = new DataSet();
                try 
                {
                    var command = new SqlCommand("GCVAccountAdditionalInfo", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlParameter AccountNumber = command.Parameters.Add("@AccountNumber", SqlDbType.VarChar, 20);
                    AccountNumber.Value = accountNumber;
                    conn.Open();
                    var adapter = new SqlDataAdapter(command);

                    adapter.Fill(accountAdditionalInfo);
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }
                return accountAdditionalInfo;
            }

            internal DataSet GetSearchPopResult(string searchval)
            {
                DataSet dsSearchResult = new DataSet();
                try
                {
                    var command = new SqlCommand("GCVSearchPOPUP", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlParameter naspID = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 20);
                    naspID.Value = searchval;
                    conn.Open();
                    var adapter = new SqlDataAdapter(command);

                    adapter.Fill(dsSearchResult);
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }
                return dsSearchResult;
            }

        #endregion

        #region auditlog

            public DataSet GetAuditLog(string naspID,string accountNumber)
            {
                DataSet auditLog = new DataSet();
                try
                {
                    var command = new SqlCommand("GCVGetUpdateLog", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    if (naspID != "")
                    {
                        SqlParameter NaspID = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 20);
                        NaspID.Value = naspID;
                    }
                    if (accountNumber != "")
                    {
                        SqlParameter AccountNumber = command.Parameters.Add("@AccountNumber", SqlDbType.VarChar, 20);
                        AccountNumber.Value = naspID;
                    }
                    conn.Open();
                    var adapter = new SqlDataAdapter(command);

                    adapter.Fill(auditLog);
                }
                catch
                {
                }
                finally
                {
                    conn.Close();
                }
                return auditLog;
            }

        #endregion


            
    }
}