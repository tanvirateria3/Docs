﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication4.DataAccess;
using System.Data;

namespace WebApplication4
{
    public partial class AuditLog : System.Web.UI.Page
    {
        SqlPlayer player = new SqlPlayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            gvAuditLogDataBound();
        }

        protected void gvAuditLog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAuditLog.PageIndex = e.NewPageIndex;
            gvAuditLogDataBound();
        }

        protected void gvAuditLogDataBound()
        {
            string naspID = Request.QueryString["naspID"];
            DataSet auditLog=player.GetAuditLog(naspID, "");
            if(auditLog != null && auditLog.Tables.Count > 0 && auditLog.Tables[0].Rows.Count > 0)
            {
                gvAuditLog.DataSource = auditLog;
                gvAuditLog.DataBind();
            }
            else
            {
                gvAuditLog.EmptyDataText = "There is no Audit trail for this NASPID";
            }
        }

    }
}