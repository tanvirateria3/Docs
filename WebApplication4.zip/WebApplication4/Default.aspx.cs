﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication4.DataAccess;
using System.Data;
using System.Data.Common;
using Microsoft.Reporting.Common;
using Microsoft.Reporting.WebForms;
using Newtonsoft.Json;

namespace WebApplication4
{
    public partial class _Default : Page
    {
        static SqlPlayer player = new SqlPlayer();
        
        List<string> accountNumbers = new List<string>();

        public string chartAnyIdData = string.Empty;
        public string returnedArray = string.Empty;
        public string chartBasicDetails = string.Empty;
        public string chartDrillData = string.Empty;
        public string chartIDrillData = string.Empty;
        public string chartWDrillData = string.Empty;
        public string chartHDrillData = string.Empty;
        public string chartABasicDetails = string.Empty;
        public string chartABasicData = string.Empty;
        public string IdEntered = string.Empty;
        public string familyId = string.Empty;
        public string billingName = string.Empty;
        public string billingAddress = string.Empty;
        public string searchCriteria = string.Empty;
        public string labelName = string.Empty;


        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnRefreshClick(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }

        #region update

            protected void btnUpdateAccount_Click(object sender, EventArgs e)
            {
                UpdateableElements updatedFields = new UpdateableElements();
                string updateNaspID = FindAccountNumbersSelected();
                if (txtCreditLimit.Text != null && !string.IsNullOrWhiteSpace(txtCreditLimit.Text))
                    updatedFields.Creditlimit = Convert.ToDecimal(txtCreditLimit.Text);
                else
                    updatedFields.Creditlimit = 0;
                updatedFields.CreditStatus = txtCreditStatus.Text;
                updatedFields.CustomerServiceModelLevel = txtCustomerServiceModelLevel.Text;
                updatedFields.RiskScore = txtRiskScore.Text;
                updatedFields.VZAccountsPayableContact = txtVZAccountsPayableContact.Text;
                updatedFields.VZClaimsMgrSupervisor = txtVZClaimsMgrSupervisor.Text;
                updatedFields.VZAccountManagerContact = txtVZAccountManagerContact.Text;
                updatedFields.VZSalesServiceTeamContact = txtVZSalesServiceTeamContact.Text;
                if (txtWholesaleID.Text != null && !string.IsNullOrWhiteSpace(txtWholesaleID.Text))
                    updatedFields.WholesaleID = Convert.ToInt32(txtWholesaleID.Text);
                else
                    updatedFields.WholesaleID = 0;
                if (rblInternationalEnterprise.SelectedIndex > -1)
                    updatedFields.InternationalEnterprise = Convert.ToBoolean(rblInternationalEnterprise.SelectedValue);
                else
                    updatedFields.InternationalEnterprise = null;
                if (rblCorporateBillingandCollections.SelectedIndex > -1)
                    updatedFields.CorporateBillingandCollections = Convert.ToBoolean(rblCorporateBillingandCollections.SelectedValue);
                else
                    updatedFields.CorporateBillingandCollections = null;
                player.UpdateAccount(updatedFields, accountNumbers, updateNaspID);
                accountNumbers.Clear();
                GetNameandDetails();
                grdSearchResultDataBound();
                DisplayChart();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);
            }

            private string FindAccountNumbersSelected()
            {
                string naspID = "";
                foreach (GridViewRow row in grdSearchResult.Rows)
                {
                    CheckBox chkRow = (row.Cells[1].FindControl("updation") as CheckBox);
                    if (chkRow.Checked)
                    {
                        int index = GetColumnIndexByName(grdSearchResult, "Account Number");
                        accountNumbers.Add(row.Cells[index].Text);
                        naspID = row.Cells[GetColumnIndexByName(grdSearchResult, "NASPID")].Text;
                    }
                }
                return naspID;
            }

            protected void btnUpdateNasp_Click(object sender, EventArgs e)
            {
                if (txtNaspACNA.Text != "" || txtCreditLimitNasp.Text != "" || txtNaspRiskScore.Text != "")
                {
                    string naspID = txtSearch.Text;
                    NaspUpdateableElements updatedFields = new NaspUpdateableElements();
                    updatedFields.ACNA = txtNaspACNA.Text;
                    updatedFields.creditLimit = Convert.ToDecimal(txtCreditLimitNasp.Text);
                    updatedFields.riskScore = txtNaspRiskScore.Text;
                    player.UpdateNaspInfo(naspID, updatedFields);
                    GetNameandDetails();
                    grdSearchResultDataBound();
                    DisplayChart();
                }
                else
                {
                    //grdSearchResult.Visible = false;
                    //updateAcct.Visible = false;
                    //btnAuditLog.Visible = false;
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage1", "alert('NO RECORDS FOUND!! Please enter a valid ID to proceed!!')", true);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage2", "alert('Please enter a valid Details to proceed!!')", true);
                    GetNameandDetails();
                    grdSearchResultDataBound();
                    DisplayChart();

                    //Session["Details"] = null;
                    return;
                }
            }

            protected void btnUpdateFamily_Click(object sender, EventArgs e)
            {
                if (txtFamilyName.Text != "")
                {
                    //Session["chartAnyIdData"] = null;
                    Session["RegionFilter"] = null;
                    Session["AccountTypeFilter"] = null;
                    Session["Details"] = null;
                    string familyID = txtSearch.Text;
                    FamilyUpdateableElements updatedFields = new FamilyUpdateableElements();
                    updatedFields.familyName = txtFamilyName.Text;
                    player.UpdateFamilyInfo(familyID, updatedFields);
                    DisplayChart();
                    GetNameandDetails();
                    grdSearchResultDataBound();
                    grdSearchResult.PageIndex = 0; 
                    billingName = txtFamilyName.Text;
                }
                else
                {
                    //grdSearchResult.Visible = false;
                    //updateAcct.Visible = false;
                    //btnAuditLog.Visible = false;
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage1", "alert('NO RECORDS FOUND!! Please enter a valid ID to proceed!!')", true);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please enter a valid Details to proceed!!')", true);
                    GetNameandDetails();
                    grdSearchResultDataBound();
                    DisplayChart();
                    //Session["Details"] = null;
                    return;
                }
            }

        #endregion


            protected void btnRegion_Click(object sender, EventArgs e)
        {
            if (Session["DSResults"] != null)
            {

                //PullChartData pcd = new PullChartData();

                string AccountType = hfFamily.Value;
                string Region = hfRegion.Value;
                string SearchFilterValue = string.Empty;
                DataSet ds = (DataSet)Session["DSResults"];
                DataView dv = ds.Tables[0].DefaultView;
                SearchFilterValue = AccountType == string.Empty ? "Region='" + Region + "'" : "AccountType='" + AccountType + "' AND Region='" + Region + "'";
                dv.RowFilter = SearchFilterValue;
                Session["RegionFilter"] = SearchFilterValue;
                grdSearchResult.DataSource = dv;
                grdSearchResult.DataBind();
                grdSearchResult.PageIndex = 0;
                GetNameandDetails();
                
                //if (Session["chartAnyIdData"] != null)
                //{
                //    chartAnyIdData = Session["chartAnyIdData"].ToString();
                //    Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);
                //}

                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);

            }
        }

        protected void btnFamily_Click(object sender, EventArgs e)
        {
            if (Session["DSResults"] != null)
            {
                //PullChartData pcd = new PullChartData();
                Session["RegionFilter"] = null;
                string str = hfFamily.Value;
                DataSet ds = (DataSet)Session["DSResults"];
                DataView dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "AccountType='" + str + "'";
                Session["AccountTypeFilter"] = "AccountType='" + str + "'";
                grdSearchResult.DataSource = dv;
                grdSearchResult.DataBind();
                grdSearchResult.PageIndex = 0;

                GetNameandDetails();
                //returnedArray = pcd.PullAnyIdData(familyId, "F", str);
                //string[] inputArgs1 = returnedArray.Split(new char[1] { '~' });
                //chartAnyIdData = inputArgs1[0];
                //Session["chartAnyIdData"] = chartAnyIdData;

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);

            }
            //Response.Write("Button method called");
        }

        protected void btnBacktoGCV_Click(object sender, EventArgs e)
        {
            Session["AccountTypeFilter"] = null;
            Session["RegionFilter"] = null;
            GetNameandDetails();
            grdSearchResultDataBound();            
        }

        protected void GetNameandDetails()
        {
            if (Session["searchCriteria"] != null)
            {
                labelName = Session["searchCriteria"].ToString();
            }

            //selectedField(labelName);
            if (Session["Details"] != null)
            {
                string Details = Session["Details"].ToString();
                string[] inputArgs = Details.Split(new char[1] { '~' });
                familyId = inputArgs[1];
                billingName = inputArgs[2];
                billingAddress = inputArgs[3];
            }
        }

        #region search

            protected void btnSearch_Click(object sender, EventArgs e)
            {
                if (txtSearch.Text == null || txtSearch.Text.Length == 0) { ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please enter an ID to proceed!!')", true); }
                else
                {
                    hfFamily.Value = "";
                    hfRegion.Value = "";
                    //Session["chartAnyIdData"] = null;
                    Session["RegionFilter"] = null;
                    Session["AccountTypeFilter"] = null;
                    selectedField(selectSearchCriteria.Value);
                    DisplayChart();
                    if (Session["Details"] == null) 
                    {                       
                        return;
                    }
                    GetNameandDetails();
                    grdSearchResultDataBound();
                    grdSearchResult.PageIndex = 0; 
                    grdSearchResult.Visible = true;
                    updateAcct.Visible = true;
                    btnAuditLog.Visible = true;
                }
            }

            protected void grdSearchResultDataBound()
            {                
                string searchCriteria = selectSearchCriteria.Value;
                string searchParameter = txtSearch.Text.ToString();
                DataSet searchResult = player.SearchAccount(searchCriteria, searchParameter);
                if (searchResult != null && searchResult.Tables.Count > 0 && searchResult.Tables[0].Rows.Count > 0)
                {
                    Session["DSResults"] = searchResult;

                    if (Session["RegionFilter"] != null)
                    {
                        DataView dv = searchResult.Tables[0].DefaultView;
                        dv.RowFilter = Session["RegionFilter"].ToString();
                        grdSearchResult.DataSource = dv;
                        grdSearchResult.DataBind();
                    }
                    else if (Session["AccountTypeFilter"] != null)
                    {
                        DataView dv = searchResult.Tables[0].DefaultView;
                        dv.RowFilter = Session["AccountTypeFilter"].ToString();
                        grdSearchResult.DataSource = dv;
                        grdSearchResult.DataBind();
                    }
                    else
                    {
                        grdSearchResult.DataSource = searchResult.Tables[0];
                        grdSearchResult.DataBind();
                    }
                                       
                }
                else
                {
                    //Session["chartAnyIdData"] = null;
                    grdSearchResult.DataSource = null;
                    grdSearchResult.DataBind(); 
                }
            }

            protected void grdSearchResult_PageIndexChanging(object sender, GridViewPageEventArgs e)
            {
                grdSearchResult.PageIndex = e.NewPageIndex;
                grdSearchResultDataBound();
                GetNameandDetails();
                //DisplayChart();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);

            }

            protected void grdSearchResult_RowDataBound(object sender, GridViewRowEventArgs e)
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    GridView gvAccountAdditionalUpdateableInfo = (GridView)e.Row.FindControl("gvAccountAdditionalUpdateableInfo");
                    GridView gvAccountAdditionalInfo = (GridView)e.Row.FindControl("gvAccountAdditionalInfo");
                    string strAccountNumber = DataBinder.Eval(e.Row.DataItem, "AccountNumber").ToString();
                    bindChildGrid( strAccountNumber, gvAccountAdditionalUpdateableInfo, gvAccountAdditionalInfo);
                }

            }

            private void bindChildGrid(string accountNumber, GridView gvAccountAdditionalUpdateableInfo, GridView gvAccountAdditionalInfo)
            {
                DataSet ds = player.AccountAdditionalInfo(accountNumber);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    gvAccountAdditionalUpdateableInfo.DataSource = ds.Tables[0];
                    gvAccountAdditionalUpdateableInfo.DataBind();
                }
                else
                {
                    gvAccountAdditionalUpdateableInfo.EmptyDataText = "No Record(s) Found !";
                    gvAccountAdditionalUpdateableInfo.DataSource = null;
                    gvAccountAdditionalUpdateableInfo.DataBind();
                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    gvAccountAdditionalInfo.DataSource = ds.Tables[1];
                    gvAccountAdditionalInfo.DataBind();
                }
                else
                {
                    gvAccountAdditionalInfo.EmptyDataText = "No Record(s) Found !";
                    gvAccountAdditionalInfo.DataSource = null;
                    gvAccountAdditionalInfo.DataBind();
                }
            }

            protected void gvAccountAdditionalUpdateableInfo_RowDataBound(object sender, GridViewRowEventArgs e)
            {

            }

            [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
            public static string[] PopupSearch(string prefixText, int count, string contextKey)
            {
                List<string> CompletionSet = new List<string>();
                string searchval = prefixText;
                DataSet dtSearchList = player.GetSearchPopResult(searchval);
                if (dtSearchList.Tables.Count > 0 && dtSearchList.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in dtSearchList.Tables[0].Rows)
                    {
                        CompletionSet.Add(dr["SearchResult"].ToString());
                    }
                }
                return CompletionSet.ToArray();
            }

        #endregion

        #region common

            private int GetColumnIndexByName(GridView grid, string name)
            {
                foreach (DataControlField col in grid.Columns)
                {
                    if (col.HeaderText.ToLower().Trim() == name.ToLower().Trim())
                    {
                        return grid.Columns.IndexOf(col);
                    }
                }
                return -1;
            }

            protected void selectedField(string SltsearchCriteria)
            {
                searchCriteria = SltsearchCriteria;
                if (SltsearchCriteria == "N")
                {
                    labelName = " NASP ID ";
                }
                else if (SltsearchCriteria == "F")
                {
                    labelName = "FAMILY ID";
                }
                else if (SltsearchCriteria == "E")
                {
                    labelName = "ECPD ID";
                }
                else if (SltsearchCriteria == "I")
                {
                    labelName = "iNASP ID";
                }
                else if (SltsearchCriteria == "W")
                {
                    labelName = "WHOLESALE ID";
                }
                Session["searchCriteria"] = labelName;
            }

        #endregion

        #region audit

        protected void btnAuditLog_Click(object sender, EventArgs e)
        {
            string naspID = txtSearch.Text;
            Response.Redirect("../GlobalCustomerView/AuditLog.aspx?naspID=" + naspID);
        }
        #endregion

        #region chart
        private void PullChartData()
        {
            throw new NotImplementedException();
        }
        // removed the string variables
        
        protected void DisplayChart()
        {
            IdEntered = txtSearch.Text;
            PullChartData pcd = new PullChartData();
            //billingName = pcd.billName;
            string str = selectSearchCriteria.Value;
            //if (searchCriteria == "F")
            //if (Session["chartAnyIdData"] != null)
            //{
            //    chartAnyIdData = Session["chartAnyIdData"].ToString();
            //    Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);
            //}

            if (str == "F")
            {
                returnedArray = pcd.PullFamilyData(IdEntered);
                if (returnedArray == "")
                {
                    grdSearchResult.Visible = false;
                    updateAcct.Visible = false;
                    btnAuditLog.Visible = false;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('NO RECORDS FOUND!! Please enter a valid ID to proceed!!')", true);
                    Session["Details"] = null;
                    return;
                    //Response.Redirect("Default.aspx");
                }
                else
                {
                string[] inputArgs = returnedArray.Split(new char[1] { '~' });
                chartBasicDetails = inputArgs[0];
                familyId = inputArgs[1];
                billingName = inputArgs[2];
                billingAddress = inputArgs[3];
                Session["Details"] = returnedArray; 
                chartDrillData = pcd.PullDrilldownData(IdEntered);
                chartIDrillData = pcd.PullDrilldownIData(IdEntered);
                chartWDrillData = pcd.PullDrilldownWData(IdEntered);
                chartHDrillData = pcd.PullDrilldownHData(IdEntered);
                //Session["chartDrillData"] = chartDrillData + '~' + chartIDrillData + '~' + chartWDrillData + '~' + chartHDrillData;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScriptgjhjk", "showPieChart();", true);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);
                }
            }
            else
            {
                returnedArray = pcd.PullAnyIdData(IdEntered, str);
                if (returnedArray == "")
                {
                    grdSearchResult.Visible = false;
                    updateAcct.Visible = false;
                    btnAuditLog.Visible = false;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('NO RECORDS FOUND!! Please enter a valid ID to proceed!!')", true);
                    Session["Details"] = null;
                    return;
                    //Response.Redirect("Default.aspx");
            }
            else
            {
                string[] inputArgs = returnedArray.Split(new char[1] { '~' });
                chartAnyIdData = inputArgs[0];
                familyId = inputArgs[1];
                billingName = inputArgs[2];
                billingAddress = inputArgs[3];
                Session["Details"] = returnedArray;
                //Session["chartAnyIdData"] = chartAnyIdData;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);
                }
            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);
        }

        protected void DisplayChildChart(string Region)
        {
            //IdEntered = txtSearch.Text;
            //PullChartData pcd = new PullChartData();
            //billingName = pcd.billName;
            if (Session["searchCriteria"] != null)
            {
                searchCriteria = Session["searchCriteria"].ToString();
            }
            if (Session["Details"] != null)
            {
                string Details = Session["Details"].ToString();
                string[] inputArgs = Details.Split(new char[1] { '~' });
                familyId = inputArgs[1];
                billingName = inputArgs[2];
                billingAddress = inputArgs[3];
            }

            //if (searchCriteria == "F")
            //{
                //returnedArray = pcd.PullFamilyData(IdEntered);
                //string[] inputArgs = returnedArray.Split(new char[1] { '~' });
                //chartBasicDetails = inputArgs[0];
                //familyId = inputArgs[1];
                //billingName = inputArgs[2];
                //billingAddress = inputArgs[3];
                //Session["Details"] = returnedArray;
                string chartDrillDetails = Session["chartDrillData"].ToString();

                string[] inputArgs1 = chartDrillDetails.Split(new char[1] { '~' });

                //chartWDrillData = inputArgs[2];
                //chartHDrillData = inputArgs[3];
                if(Region == "D")
                    chartAnyIdData = inputArgs1[0];
                else
                    chartAnyIdData = inputArgs1[1];

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);


            //}
            //else
            //{
            //    returnedArray = pcd.PullAnyIdData(IdEntered, searchCriteria);
            //    string[] inputArgs = returnedArray.Split(new char[1] { '~' });
            //    chartAnyIdData = inputArgs[0];
            //    familyId = inputArgs[1];
            //    billingName = inputArgs[2];
            //    billingAddress = inputArgs[3];
            //    Session["Details"] = returnedArray;
            //    Page.ClientScript.RegisterStartupScript(this.GetType(), "anychartdata", "showAnyIdData();", true);
            //}
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "ShowHideDetails();", true);
        }


        #endregion;


    }
}