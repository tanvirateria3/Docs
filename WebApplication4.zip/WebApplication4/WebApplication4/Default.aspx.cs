﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication4.DataAccess;
using System.Data;
using System.Data.Common;
using Microsoft.Reporting.Common;
using Microsoft.Reporting.WebForms;

namespace WebApplication4
{
    public partial class _Default : Page
    {
        SqlPlayer player = new SqlPlayer();
        UpdateableElements updatedFields = new UpdateableElements();
        static DataSet searchResult = new DataSet();
        static List<string> accountNumbers = new List<string>();
        protected void Page_Load(object sender, EventArgs e)
        {
            /* public string AccountNumber { get; set; }
        public Nullable<decimal> Creditlimit { get; set; }
        public string RiskScore { get; set; }
        public string CustomerServiceModelLevel { get; set; }
        public string CreditStatus { get; set; }
        public string  { get; set; }
        public string VZAccountsPayableContact { get; set; }
        public string VZClaimsMgrSupervisor { get; set; }
        public string VZSalesServiceTeamContact { get; set; }
        public Nullable<int> WholesaleID { get; set; }
        public Nullable<bool> InternationalEnterprise { get; set; }
        public Nullable<bool> CorporateBillingandCollections { get; set; }
             
             
             
             WholesaleID
             InternationalEnterprise
             CorporateBillingandCollections*/
        }
        protected void btnUpdateAccount_Click(object sender, EventArgs e)
        {
            FindAccountNumbersSelected();
            updatedFields.Creditlimit = Convert.ToDecimal(txtCreditLimit.Text);
            updatedFields.CreditStatus = txtCreditStatus.Text;
            updatedFields.CustomerServiceModelLevel = txtCustomerServiceModelLevel.Text;
            updatedFields.RiskScore = txtRiskScore.Text;
            updatedFields.VZAccountsPayableContact=txtVZAccountsPayableContact.Text;
            updatedFields.VZClaimsMgrSupervisor = txtVZClaimsMgrSupervisor.Text;
            updatedFields.VZAccountManagerContact=txtVZAccountManagerContact.Text;
            updatedFields.VZSalesServiceTeamContact = txtVZSalesServiceTeamContact.Text;
            updatedFields.WholesaleID = Convert.ToInt32(txtWholesaleID.Text);

            player.UpdateAccount(updatedFields);
        }

        private void FindAccountNumbersSelected()
        {
            foreach(GridViewRow row in grdSearchResult.Rows)
            {
                //if()
                //{

                //}
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string naspID = txtSearch.Value.ToString();
            searchResult = player.SearchAccount(naspID);
            grdSearchResultDataBound();
            grdSearchResult.Visible = true;
        }

        protected void grdSearchResultDataBound()
        {
            grdSearchResult.DataSource = searchResult.Tables[0];
            grdSearchResult.DataBind();
        }

        protected void grdSearchResult_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdSearchResult.PageIndex = e.NewPageIndex;
            grdSearchResultDataBound();
        }

        protected void grdSearchResult_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                
            }

        }
        

    }
}