﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace WebApplication4.DataAccess
{
    public class SqlPlayer
    {
        SqlConnection conn = new SqlConnection(ConnectionString.Connect());
        public void UpdateAccount(UpdateableElements updatedFields)
        {
            
            try
            {
                var command = new SqlCommand("uspGCVUpdate", conn);
                command.CommandType = CommandType.StoredProcedure;
                SqlParameter AccountNumber = command.Parameters.Add("@AccountNumber", SqlDbType.VarChar, 20);
                SqlParameter CreditLimit = command.Parameters.Add("@Creditlimit", SqlDbType.Money);
                SqlParameter RiskScore = command.Parameters.Add("@RiskScore", SqlDbType.VarChar, 10);
                SqlParameter CustomerServiceModelLevel = command.Parameters.Add("@CustomerServiceModelLevel", SqlDbType.VarChar, 100);
                SqlParameter CreditStatus = command.Parameters.Add("@CreditStatus", SqlDbType.VarChar, 20);
                SqlParameter VZAccountManagerContact = command.Parameters.Add("@VZAccountManagerContact", SqlDbType.VarChar, 100);
                SqlParameter VZAccountsPayableContact = command.Parameters.Add("@VZAccountsPayableContact", SqlDbType.VarChar, 100);
                SqlParameter VZClaimsMgrSupervisor = command.Parameters.Add("@VZClaimsMgrSupervisor", SqlDbType.VarChar, 100);
                SqlParameter VZSalesServiceTeamContact = command.Parameters.Add("@VZSalesServiceTeamContact", SqlDbType.VarChar, 100);
                SqlParameter WholesaleID = command.Parameters.Add("@WholesaleID", SqlDbType.Int);
                SqlParameter InternationalEnterprise = command.Parameters.Add("@InternationalEnterprise", SqlDbType.Int);
                SqlParameter CorporateBillingandCollections = command.Parameters.Add("@CorporateBillingandCollections", SqlDbType.Int);
                AccountNumber.Value = "4016584374644";
                CreditLimit.Value = updatedFields.Creditlimit;
                RiskScore.Value = updatedFields.RiskScore;
                CustomerServiceModelLevel.Value = updatedFields.CustomerServiceModelLevel;
                CreditStatus.Value = updatedFields.CreditStatus;
                //VZAccountManagerContact.Value = customer.VZAccountManagerContact;
                VZAccountsPayableContact.Value = updatedFields.VZAccountsPayableContact;
                VZClaimsMgrSupervisor.Value = updatedFields.VZClaimsMgrSupervisor;
                //VZSalesServiceTeamContact.Value = customer.VZSalesServiceTeamContact;
                //WholesaleID.Value = customer.WholesaleID;
                //InternationalEnterprise.Value = customer.InternationalEnterprise;
                //CorporateBillingandCollections.Value = customer.CorporateBillingandCollections;

                {
                    conn.Open();
                    int errorCount = command.ExecuteNonQuery();
                }
            }
            catch(NullReferenceException)
            {
                
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet SearchAccount(string NaspID)
        {
            DataSet dsSearchResult = new DataSet();
            try
            {
                var command = new SqlCommand("GCVSearchByNASPID", conn);
                command.CommandType = CommandType.StoredProcedure;
                SqlParameter naspID = command.Parameters.Add("@NASPID", SqlDbType.VarChar, 20);
                naspID.Value = NaspID;
                conn.Open();
                var adapter = new SqlDataAdapter(command);

                adapter.Fill(dsSearchResult);
            }
            catch
            {
            }
            finally
            {
                conn.Close();
            }

            return dsSearchResult;
        }
    }
}