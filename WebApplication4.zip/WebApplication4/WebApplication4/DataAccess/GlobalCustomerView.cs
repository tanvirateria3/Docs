﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.DataAccess
{
    public class GlobalCustomerView : UpdateableElements
    {
        public long GlobalCustomerViewID { get; set; }
        public string CustomerName { get; set; }
        public string NASPID { get; set; }
        public string NASPName { get; set; }
        public string FamilyID { get; set; }
        public string FamilyName { get; set; }
        public string ECPDID { get; set; }
        public string ECPDName { get; set; }
        public string DUNSNumberUltimate { get; set; }
        public string DUNSNumberHeadquarters { get; set; }
        public string DUNSNumberLocation { get; set; }
        public string CustomerExecutives { get; set; }
        public string CustomerAddress { get; set; }
        public string ACNA { get; set; }
        public string UPD { get; set; }
        public Nullable<int> ECPDIDtotallines { get; set; }
        public Nullable<int> Contracttotallines { get; set; }
        public string VZCollMgrSupervisor { get; set; }
        public Nullable<bool> GlobalSensitiveAccountManagement { get; set; }
        public Nullable<bool> DomesticWholesale { get; set; }
        public Nullable<bool> InternationalWholesale { get; set; }
        public Nullable<bool> Federal { get; set; }
        public Nullable<bool> EnterpriseWireline { get; set; }
        public Nullable<bool> EnterpriseWireless { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public Nullable<System.DateTime> LastmodifiedDate { get; set; }
    }
}